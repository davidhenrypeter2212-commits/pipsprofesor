import Link from "next/link";
import { Nav } from "../components/Nav";
import { Card } from "../components/ui";

export default function Home() {
 return <><Nav/><main>
  <section className="mx-auto max-w-7xl px-5 py-24 text-center sm:py-32">
   <div className="mx-auto max-w-4xl">
    <span className="rounded-full border border-cyan-300/20 bg-cyan-300/5 px-4 py-2 text-xs font-semibold text-cyan-200">SIMULATED PROP EVALUATIONS</span>
    <h1 className="mt-7 text-5xl font-black tracking-tight sm:text-7xl">Trade with a plan.<br/><span className="text-cyan-300">Earn your funding.</span></h1>
    <p className="mx-auto mt-6 max-w-2xl text-lg leading-8 text-white/55">Pips Professor gives traders structured evaluation accounts, clear rules and a professional workspace to prove consistency.</p>
    <div className="mt-9 flex justify-center gap-3"><Link className="rounded-xl bg-white px-6 py-3 font-bold text-black" href="/signup">Start evaluation</Link><a className="rounded-xl border border-white/10 px-6 py-3 font-semibold" href="#accounts">View accounts</a></div>
   </div>
  </section>
  <section id="accounts" className="mx-auto grid max-w-7xl gap-5 px-5 pb-24 md:grid-cols-3">
   {[["Starter","$10,000","$89"],["Pro","$25,000","$179"],["Elite","$50,000","$299"]].map(([name,size,price])=>
    <Card key={name}><p className="text-sm text-white/50">{name}</p><p className="mt-2 text-4xl font-black">{size}</p><p className="mt-3 text-white/55">Evaluation buying price</p><p className="mt-7 text-2xl font-bold">{price}</p><Link className="mt-5 block rounded-xl bg-white px-4 py-3 text-center font-semibold text-black" href="/signup">Choose account</Link></Card>)}
  </section>
 </main></>
}
