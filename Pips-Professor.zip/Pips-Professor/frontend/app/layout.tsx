import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Pips Professor",
  description: "Professional simulated prop-trading evaluations."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
