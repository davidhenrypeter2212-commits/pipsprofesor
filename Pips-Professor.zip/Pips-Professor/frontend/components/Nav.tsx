import Link from "next/link";
export function Nav({authed=false}:{authed?:boolean}) {
 return <header className="sticky top-0 z-20 border-b border-white/10 bg-[#07090d]/85 backdrop-blur-xl">
  <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4">
   <Link href="/" className="font-black tracking-tight text-xl">Pips <span className="text-cyan-300">Professor</span></Link>
   <nav className="flex items-center gap-2 text-sm text-white/70">
    <Link className="hidden rounded-lg px-3 py-2 hover:bg-white/5 sm:block" href="/#accounts">Accounts</Link>
    {authed ? <Link className="rounded-lg bg-white px-4 py-2 font-semibold text-black" href="/dashboard">Dashboard</Link> :
      <><Link className="rounded-lg px-3 py-2 hover:bg-white/5" href="/login">Login</Link><Link className="rounded-lg bg-white px-4 py-2 font-semibold text-black" href="/signup">Get started</Link></>}
   </nav>
  </div>
 </header>
}
