export function Button({children, ...p}: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return <button {...p} className={`rounded-xl px-4 py-2.5 text-sm font-semibold transition hover:opacity-90 disabled:opacity-50 ${p.className||"bg-white text-black"}`}>{children}</button>
}
export function Card({children, className=""}: {children: React.ReactNode; className?: string}) {
  return <div className={`rounded-2xl border border-white/10 bg-white/[.035] p-5 shadow-2xl shadow-black/10 ${className}`}>{children}</div>
}
export function Field({label, ...p}: React.InputHTMLAttributes<HTMLInputElement> & {label:string}) {
  return <label className="grid gap-2 text-sm text-white/70">{label}<input {...p} className={`rounded-xl border border-white/10 bg-black/20 px-3 py-3 text-white outline-none focus:border-white/30 ${p.className||""}`} /></label>
}
