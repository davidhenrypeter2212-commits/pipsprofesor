# Pips Professor

A production-oriented starter for a prop-trading evaluation platform.

## Architecture
- Frontend: Next.js + TypeScript + Tailwind CSS
- Backend: Node.js + Express + Prisma
- Database: PostgreSQL
- Authentication: JWT stored in an HttpOnly cookie
- Trading engine: intentionally isolated behind backend services so a broker/market-data provider can be integrated later.

## Feature map
1. **Authentication** — signup, login, logout, bcrypt password hashing, HttpOnly JWT session cookie, protected API routes.
2. **Evaluation accounts** — Starter/Pro/Elite simulated accounts with starting balance, target, drawdown and status.
3. **Trader dashboard** — account cards, equity/profit/target progress, empty/loading/error states.
4. **Trade journal** — protected simulated trade-entry API and responsive trade form.
5. **Settings** — protected profile update endpoint and settings UI.

## Included
- Marketing homepage
- Signup/login/logout
- Protected dashboard
- Evaluation account creation
- Account status/progress
- Basic trade submission API
- Profile/settings page
- Responsive dark financial UI
- Validation and consistent error responses

## Important production boundary
This implementation is an application foundation, not a live brokerage or custody system. It uses simulated evaluation trading. Real-money funding, broker execution, KYC/AML, payments, legal terms, jurisdictional restrictions, and live market data require separate regulated/provider integrations and legal review.

## Setup
1. Install Node.js 20+ and PostgreSQL.
2. Copy `backend/.env.example` to `backend/.env`.
3. Set `DATABASE_URL` and a long random `JWT_SECRET`.
4. Run `npm install` in the root, then `npm run install:all`.
5. From `backend`, run `npx prisma migrate dev --name init`.
6. Start both apps with `npm run dev`.
7. Frontend: http://localhost:3000
8. Backend health: http://localhost:4000/api/health

## Production
- Use managed PostgreSQL.
- Set `NODE_ENV=production`.
- Use HTTPS.
- Configure a real domain and strict CORS origin.
- Put the backend behind a reverse proxy/load balancer.
- Store secrets in your hosting provider's secret manager.
- Add provider integrations for payments, KYC/AML, market data and broker execution before commercial launch.

## Database
The Prisma schema contains User, EvaluationAccount and Trade tables with foreign-key relationships and indexes. Run `npx prisma migrate dev --name init` after configuring PostgreSQL.
